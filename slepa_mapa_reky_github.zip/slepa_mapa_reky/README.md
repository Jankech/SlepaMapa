# Slepá mapa Česka – řeky

Jednoduché cvičení v HTML/CSS/JavaScriptu pro GitHub Pages.

## Spuštění
Otevři `index.html` v prohlížeči.

## Publikování přes GitHub Pages
1. Vytvoř nový GitHub repository.
2. Nahraj `index.html` (a tento README).
3. V repository otevři **Settings → Pages**.
4. V části **Build and deployment** vyber **Deploy from a branch**.
5. Vyber branch `main` a složku `/ (root)`, potvrď **Save**.
6. Po chvíli bude stránka dostupná na `https://TVUJ-UCET.github.io/NAZEV-REPOSITARE/`.

Poznámka: mapa a průběhy řek jsou záměrně schematické, nejde o přesnou kartografickou mapu.
